import React, { useState } from "react";
import axios from "axios";

const AddExpenseForm = ({ onAddExpense }) => {
  const [formData, setFormData] = useState({
    description: "",
    amount: "",
    date: "",
    category: "",
  });

  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const url = "http://localhost:8989/expenses/";  // Backend POST URL
  
    try {
      const response = await axios.post(url, formData);
      setMessage("Expense added successfully!");
  
      // Notify the parent component to update the list
      onAddExpense(response.data); // Assuming the backend sends back the added expense
  
      // Reset the form
      setFormData({ description: "", amount: "", date: "",category: "", });
    } catch (error) {
      console.error("Error adding expense:", error);
      setMessage("Failed to add expense. Please try again.");
    }
  };

  return (
    <div>
      <h2>Add Expense</h2>
      {message && <p>{message}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Description:</label>
          <input
            type="text"
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Category</label>
          <input
            type="text"
            name="category"
            value={formData.category}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Amount:</label>
          <input
            type="number"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Date:</label>
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Add Expense</button>
      </form>
    </div>
  );
};

export default AddExpenseForm;