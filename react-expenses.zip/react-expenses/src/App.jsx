
import React, { useState, useEffect } from "react";
import axios from "axios";
import ExpensesList from "./components/ExpenseList";
import AddExpenseForm from "./components/AddExpenseForm";


function App() {
  const [expenses, setExpenses] = useState([]);

  // Fetch expenses from the backend on initial load
  useEffect(() => {
    const fetchExpenses = async () => {
      try {
        const response = await axios.get("http://localhost:8989/expenses");
        setExpenses(response.data); // Update the state with fetched expenses
      } catch (error) {
        console.error("Error fetching expenses:", error);
      }
    };

    fetchExpenses();
  }, []);

  // Add a new expense to the state
  const handleAddExpense = (newExpense) => {
    setExpenses((prevExpenses) => [newExpense, ...prevExpenses]);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Expense Tracker</h1>
      {/* Add Expense Form */}
      <AddExpenseForm onAddExpense={handleAddExpense} />
      {/* Expense List */}
      <ExpensesList expenses={expenses} />
    </div>
  );
}

export default App;
