const { DataTypes } = require('sequelize');
const sequelize = require('./index');

const Expense = sequelize.define('Expense', {
  amount: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
  category: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
}, {
  tableName: 'expenses',    // Specify the existing table name
  timestamps: false,        // Disable Sequelize's automatic `createdAt` and `updatedAt` columns
});
module.exports = Expense;