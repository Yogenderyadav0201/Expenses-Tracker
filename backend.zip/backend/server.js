require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./models/index');
const expenseRoutes = require('./routes/expenses');
const cors = require("cors");

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Routes
app.use('/expenses', expenseRoutes);

// Sync database and start server
sequelize.sync().then(() => {
  app.listen(8989, () => console.log('Server running on port 8989'));
});